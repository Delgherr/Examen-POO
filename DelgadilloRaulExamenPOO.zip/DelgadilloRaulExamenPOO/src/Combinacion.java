//J.R.D.H - 1190267
import java.util.ArrayList;
import java.util.Collections;

public abstract class Combinacion implements Desempate {

    public String identificarCombinacion(ArrayList<String> resultados) {
        Collections.sort(resultados);// Ordenar el ArrayList

        // Verificar si hay quintilla
        if (resultados.get(0).equals(resultados.get(4))) {
            return "Quintilla";
        }

        // Verificar si hay poker
        if (resultados.get(0).equals(resultados.get(3)) || resultados.get(1).equals(resultados.get(4))) {
            return "Poker";
        }

        // Verificar si hay full
        if ((resultados.get(0).equals(resultados.get(2)) && resultados.get(3).equals(resultados.get(4))) ||
                (resultados.get(0).equals(resultados.get(1)) && resultados.get(2).equals(resultados.get(4)))) {
            return "Full";
        }

        // Verificar si hay tercia
        if (resultados.get(0).equals(resultados.get(2)) || resultados.get(1).equals(resultados.get(3)) ||
                resultados.get(2).equals(resultados.get(4))) {
            return "Tercia";
        }

        // Verificar si hay dos pares
        if ((resultados.get(0).equals(resultados.get(1)) && resultados.get(2).equals(resultados.get(3))) ||
                (resultados.get(0).equals(resultados.get(1)) && resultados.get(3).equals(resultados.get(4))) ||
                (resultados.get(1).equals(resultados.get(2)) && resultados.get(3).equals(resultados.get(4)))) {
            return "Dos pares";
        }

        // Verificar si hay un par
        if (resultados.get(0).equals(resultados.get(1)) || resultados.get(1).equals(resultados.get(2)) ||
                resultados.get(2).equals(resultados.get(3)) || resultados.get(3).equals(resultados.get(4))) {
            return "Un par";
        }

        return "Ninguna combinación";
    }

    // Método para obtener el valor de la combinación según las reglas del juego
    public static int obtenerValorCombinacion(String combinacion) {
        switch (combinacion) {
            case "Quintilla":
                return 6;
            case "Poker":
                return 5;
            case "Full":
                return 4;
            case "Tercia":
                return 3;
            case "Dos pares":
                return 2;
            case "Un par":
                return 1;
            default:
                return 0;
        }
    }
}