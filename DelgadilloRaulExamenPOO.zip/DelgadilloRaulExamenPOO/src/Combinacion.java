/*import java.util.ArrayList;
import java.util.Collections;

public abstract class Combinacion {
    // Método para identificar la combinación obtenida
    public String identificarCombinacion(ArrayList<String> resultados) {
        // Ordenar los resultados para facilitar las validaciones
        Collections.sort(resultados);

        // Contadores para cada combinación
        boolean quintilla = false;
        boolean poker = false;
        boolean full = false;
        boolean tercia = false;
        boolean dosPares = false;
        boolean unPar = false;

        // Verificar si hay quintilla
        if (resultados.get(0).equals(resultados.get(4))) {
            quintilla = true;
        }

        // Verificar si hay poker
        if (resultados.get(0).equals(resultados.get(3)) || resultados.get(1).equals(resultados.get(4))) {
            poker = true;
        }

        // Verificar si hay full
        if ((resultados.get(0).equals(resultados.get(2)) && resultados.get(3).equals(resultados.get(4))) ||
                (resultados.get(0).equals(resultados.get(1)) && resultados.get(2).equals(resultados.get(4)))) {
            full = true;
        }

        // Verificar si hay tercia
        if (resultados.get(0).equals(resultados.get(2)) ||
                resultados.get(1).equals(resultados.get(3)) ||
                resultados.get(2).equals(resultados.get(4))) {
            tercia = true;
        }

        // Verificar si hay dos pares
        if ((resultados.get(0).equals(resultados.get(1)) && resultados.get(2).equals(resultados.get(3))) ||
                (resultados.get(0).equals(resultados.get(1)) && resultados.get(3).equals(resultados.get(4))) ||
                (resultados.get(1).equals(resultados.get(2)) && resultados.get(3).equals(resultados.get(4))) ||
                (resultados.get(0).equals(resultados.get(1)) && resultados.get(2).equals(resultados.get(4))) ||
                (resultados.get(0).equals(resultados.get(2)) && resultados.get(3).equals(resultados.get(4))) ||
                (resultados.get(0).equals(resultados.get(3)) && resultados.get(2).equals(resultados.get(4)))) {
            dosPares = true;
        }

        // Verificar si hay un par
        if (resultados.get(0).equals(resultados.get(1)) ||
                resultados.get(1).equals(resultados.get(2)) ||
                resultados.get(2).equals(resultados.get(3)) ||
                resultados.get(3).equals(resultados.get(4))) {
            unPar = true;
        }

        // Devolver el nombre de la combinación obtenida
        if (quintilla) return "Quintilla";
        if (poker) return "Poker";
        if (full) return "Full";
        if (tercia) return "Tercia";
        if (dosPares) return "Dos pares";
        if (unPar) return "Un par";
        return "Ninguna combinación";
    }
}*/
import java.util.ArrayList;
import java.util.Collections;

public abstract class Combinacion {

    public String identificarCombinacion(ArrayList<String> resultados) {
        Collections.sort(resultados);// Ordenar el ArrayList

        // Verificar si hay quintilla
        if (resultados.get(0).equals(resultados.get(4))) {
            return "Quintilla";
        }

        // Verificar si hay poker
        if (resultados.get(0).equals(resultados.get(3)) || resultados.get(1).equals(resultados.get(4))) {
            return "Poker";
        }

        // Verificar si hay full
        if ((resultados.get(0).equals(resultados.get(2)) && resultados.get(3).equals(resultados.get(4))) ||
                (resultados.get(0).equals(resultados.get(1)) && resultados.get(2).equals(resultados.get(4)))) {
            return "Full";
        }

        // Verificar si hay tercia
        if (resultados.get(0).equals(resultados.get(2)) ||
                resultados.get(1).equals(resultados.get(3)) ||
                resultados.get(2).equals(resultados.get(4))) {
            return "Tercia";
        }

        // Verificar si hay dos pares
        if ((resultados.get(0).equals(resultados.get(1)) && resultados.get(2).equals(resultados.get(3))) ||
                (resultados.get(0).equals(resultados.get(1)) && resultados.get(3).equals(resultados.get(4))) ||
                (resultados.get(1).equals(resultados.get(2)) && resultados.get(3).equals(resultados.get(4)))) {
            return "Dos pares";
        }

        // Verificar si hay un par
        if (resultados.get(0).equals(resultados.get(1)) ||
                resultados.get(1).equals(resultados.get(2)) ||
                resultados.get(2).equals(resultados.get(3)) ||
                resultados.get(3).equals(resultados.get(4))) {
            return "Un par";
        }

        return "Ninguna combinación";
    }
}
