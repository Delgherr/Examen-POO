public class Jugador {
    private String nombre;
    private int numero;
    private int puntuacion;
    private static int numRonda;

    public Jugador(String nombre) {
        this.nombre = nombre;
        this.numero = 0; // Inicializamos el número en 0, se actualizará después del lanzamiento del dado.
        this.puntuacion = 0;
        this.numRonda = 0;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public static int getNumRonda() {
        return numRonda;
    }

    public static void setNumRonda(int numRonda) {
        Jugador.numRonda = numRonda;
    }
}
