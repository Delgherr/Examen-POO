import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;
        UIControl ui = new UIControl();

        // Bucle del menú
        while (true) {
            try {
                System.out.println("\n\nMenu:");
                System.out.println("1. Jugar Juego Clasico");
                System.out.println("2. Jugar con dados de 6 colores diferentes");
                System.out.println("3. Jugar con dado de 6 letras diferentes");
                System.out.println("4. Jugar con dados de 6 palabras diferentes");
                System.out.println("5. Salir");
                System.out.print("Selecciona una opción: ");

                opcion = scanner.nextInt();
                scanner.nextLine(); // Consumir el carácter de nueva línea

                switch (opcion) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                        ui.jugarJuegoClasico(scanner, opcion);
                        break;
                    case 5:
                        System.out.println("Fin del Juego");
                        scanner.close();
                        return; // Salir del programa cuando se elija la opción 5
                    default:
                        System.out.println("La opción seleccionada no está disponible");
                }
            } catch (InputMismatchException e) {
                System.out.println("Por favor, ingresa un número entero.");
                scanner.nextLine(); // Limpiar el búfer de entrada
            }
        }
    }
}
