//J.R.D.H - 1190267
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean enEjecucion = true;
        PartidaCubilete juego = new PartidaCubilete();

        while (enEjecucion) {
            try {
                System.out.println("Menu:");
                System.out.println("1. Jugar Juego Clasico");
                System.out.println("2. Jugar con dados de 6 colores diferentes");
                System.out.println("3. Jugar con dado de 6 letras diferentes");
                System.out.println("4. Jugar con dados de 6 palabras diferentes");
                System.out.println("5. Salir");
                System.out.print("Selecciona una opción: ");

                int opcion = scanner.nextInt();
                scanner.nextLine(); // Consumir el carácter de nueva línea

                switch (opcion) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                        juego.jugarJuegoClasico(scanner, opcion);
                        break;
                    case 5:
                        System.out.println("\nFin del Juego");
                        scanner.close();
                        enEjecucion = false;
                        break; // Salir del bucle cuando se elija la opción 5
                    default:
                        System.out.println("\nLa opción seleccionada no está disponible");
                }
            } catch (InputMismatchException e) {
                System.out.println("\nPor favor, ingresa un número entero.");
                scanner.nextLine(); // Limpiar el búfer de entrada
            }
        }
    }
}