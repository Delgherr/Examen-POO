import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.List;
import java.util.Random;

public class UIControl extends Combinacion implements Desempate {

    private boolean primeraRonda = true;
    private int numRondas = 4;
    private int rondaActual = 0;
    private String[] nombresJugadores;
    private int [] puntajeJugadores = {0,0,0,0};
    private ArrayList<Integer> ganadores;
    Random rand = new Random();


    // Método para jugar el juego clásico de cubilete
    public void jugarJuegoClasico(Scanner scanner, int tipoDado) {
        List<String> valoresOriginales = new ArrayList<>();
        if (tipoDado == 1) {
            valoresOriginales.add(Dado.valores[0]);
            valoresOriginales.add(Dado.valores[1]);
            valoresOriginales.add(Dado.valores[2]);
            valoresOriginales.add(Dado.valores[3]);
            valoresOriginales.add(Dado.valores[4]);
            valoresOriginales.add(Dado.valores[5]);
        } else if (tipoDado == 2) {
            valoresOriginales.add(Dado.valores2[0]);
            valoresOriginales.add(Dado.valores2[1]);
            valoresOriginales.add(Dado.valores2[2]);
            valoresOriginales.add(Dado.valores2[3]);
            valoresOriginales.add(Dado.valores2[4]);
            valoresOriginales.add(Dado.valores2[5]);
        } else if (tipoDado == 3) {
            valoresOriginales.add(Dado.valores3[0]);
            valoresOriginales.add(Dado.valores3[1]);
            valoresOriginales.add(Dado.valores3[2]);
            valoresOriginales.add(Dado.valores3[3]);
            valoresOriginales.add(Dado.valores3[4]);
            valoresOriginales.add(Dado.valores3[5]);
        } else if (tipoDado == 4) {
            valoresOriginales.add(Dado.valores4[0]);
            valoresOriginales.add(Dado.valores4[1]);
            valoresOriginales.add(Dado.valores4[2]);
            valoresOriginales.add(Dado.valores4[3]);
            valoresOriginales.add(Dado.valores4[4]);
            valoresOriginales.add(Dado.valores4[5]);
        }
        do {
            if (primeraRonda) {
                // Solicitar el número de rondas
                System.out.print("\nIngrese el número de rondas: ");
                numRondas = scanner.nextInt();
                System.out.print("\nIngrese el número de jugadores (2-4): ");
                int numJugadores = scanner.nextInt();

                if (numJugadores < 2 || numJugadores > 4) {
                    System.out.println("\nNúmero de jugadores inválido. El juego solo admite de 2 a 4 jugadores.");
                    return;
                }

                // Array para almacenar los nombres de los jugadores
                nombresJugadores = new String[numJugadores];

                // Array para almacenar los valores de los lanzamientos
                int[] valoresLanzamientos = new int[numJugadores];

                // Set para validar que no haya repeticiones de lanzamientos
                Set<Integer> lanzamientosRealizados = new HashSet<>();

                // Solicitar los nombres de los jugadores
                for (int i = 0; i < numJugadores; i++) {
                    System.out.print("\nIngrese el nombre del jugador " + (i + 1) + ": ");
                    nombresJugadores[i] = scanner.next();
                }

                // Simular el lanzamiento de un dado para cada jugador
                /*for (int i = 0; i < numJugadores; i++) {
                    int lanzamiento;
                    do {
                        lanzamiento = (int) (Math.random() * 6) + 1; // Simular lanzamiento de un dado
                    } while (lanzamientosRealizados.contains(lanzamiento));
                    valoresLanzamientos[i] = lanzamiento;
                    lanzamientosRealizados.add(lanzamiento);
                    System.out.println("Lanzamiento de " + nombresJugadores[i] + ": " + valoresLanzamientos[i]);
                }*/

                for (int i = 0; i < numJugadores; i++) {
                    int lanzamiento;
                    do {
                        lanzamiento = rand.nextInt(valoresOriginales.size()); // Simular lanzamiento de un dado
                    } while (lanzamientosRealizados.contains(lanzamiento));
                    valoresLanzamientos[i] = lanzamiento;
                    lanzamientosRealizados.add(lanzamiento);
                    System.out.println("Lanzamiento de " + nombresJugadores[i] + ": " + valoresOriginales.get(lanzamiento));
                }

                // Ordenar los valores de los lanzamientos de mayor a menor
                for (int i = 0; i < numJugadores - 1; i++) {
                    for (int j = 0; j < numJugadores - i - 1; j++) {
                        if (valoresLanzamientos[j] < valoresLanzamientos[j + 1]) {
                            int temp = valoresLanzamientos[j];
                            valoresLanzamientos[j] = valoresLanzamientos[j + 1];
                            valoresLanzamientos[j + 1] = temp;

                            // Intercambiar nombres de jugadores de acuerdo a la posición del lanzamiento
                            String tempNombre = nombresJugadores[j];
                            nombresJugadores[j] = nombresJugadores[j + 1];
                            nombresJugadores[j + 1] = tempNombre;
                        }
                    }
                }

                // Mostrar el orden de los jugadores según el resultado de los lanzamientos
                System.out.println("\nOrden de los jugadores:");
                for (int i = 0; i < numJugadores; i++) {
                    System.out.println("Puesto " + (i + 1) + ": " + nombresJugadores[i]);
                }

                primeraRonda = false; // Marca que la primera ronda ha terminado
            }
            System.out.println("\n\nRonda "+(rondaActual+1));

            int numJugadores = nombresJugadores.length;
            ArrayList<String>[] resultados = new ArrayList[numJugadores];
            int maxValor = -1;
            ArrayList<Integer> posiblesGanadores = new ArrayList<>();




            int tiradas = 0; // Inicializar la variable tiradas fuera del bucle del jugador 1
            for (int i = 0; i < numJugadores; i++) {
                System.out.println("\nJugador " + (i + 1) + ":");
                JuegoClasico juego = new JuegoClasico(5, tipoDado);
                ArrayList<String> lanzamiento = new ArrayList<>();
                for (String valor : juego.getDados()) {
                    lanzamiento.add(valor);
                }
                Collections.sort(lanzamiento, (a, b) -> valorNumerico(b) - valorNumerico(a)); // Ordenar de mayor a menor
                resultados[i] = lanzamiento;
                System.out.println("Resultado del lanzamiento:");
                for (String valor : lanzamiento) {
                    System.out.print("[" + valor + "] ");
                }
                System.out.println();

                // Preguntar al jugador si quiere volver a tirar hasta tres veces
                if (i == 0) {
                    while (tiradas < 2) {
                        System.out.print("¿Quieres volver a tirar? (s/n): ");
                        String respuesta = scanner.next();
                        if (respuesta.equalsIgnoreCase("s")) {
                            System.out.print("Ingrese la posición de los dados que quieres volver a tirar (separados por comas): ");
                            String posicionesStr = scanner.next();
                            String[] posiciones = posicionesStr.split(",");
                            List<String> valoresDisponibles = new ArrayList<>(valoresOriginales);

                            // Obtener los valores disponibles para las posiciones seleccionadas
                            for (String posStr : posiciones) {
                                int pos = Integer.parseInt(posStr.trim()) - 1; // Convertir a índice base 0
                                String valor = valoresDisponibles.remove(new Random().nextInt(valoresDisponibles.size()));
                                lanzamiento.set(pos, valor);
                            }

                            // Mostrar todos los valores de los dados después de la tirada
                            System.out.println("Lanzamiento actualizado:");
                            for (int k = 0; k < 5; k++) {
                                System.out.print("[" + lanzamiento.get(k) + "] ");
                            }
                            System.out.println();
                            tiradas++;
                        } else {
                            break; // El jugador decide no tirar más dados
                        }
                    }
                } else {
                    // Preguntar a los demás jugadores si quieren volver a tirar la misma cantidad de veces que el primer jugador
                    for (int j = 0; j < tiradas; j++) {
                        System.out.print("¿Quieres volver a tirar? (s/n): ");
                        String respuesta = scanner.next();
                        if (respuesta.equalsIgnoreCase("s")) {
                            System.out.print("Ingrese la posición de los dados que quieres volver a tirar (separados por comas): ");
                            String posicionesStr = scanner.next();
                            String[] posiciones = posicionesStr.split(",");
                            List<String> valoresDisponibles = new ArrayList<>(valoresOriginales);

                            // Obtener los valores disponibles para las posiciones seleccionadas
                            for (String posStr : posiciones) {
                                int pos = Integer.parseInt(posStr.trim()) - 1; // Convertir a índice base 0
                                String valor = valoresDisponibles.remove(new Random().nextInt(valoresDisponibles.size()));
                                lanzamiento.set(pos, valor);
                            }

                            // Mostrar todos los valores de los dados después de la tirada
                            System.out.println("Lanzamiento actualizado:");
                            for (int k = 0; k < 5; k++) {
                                System.out.print("[" + lanzamiento.get(k) + "] ");
                            }
                            System.out.println();
                        } else {
                            break; // El jugador decide no tirar más dados
                        }
                    }
                }

                String combinacion = identificarCombinacion(lanzamiento);
                System.out.println("Combinación obtenida: " + combinacion);

                // Obtener el valor numérico de la combinación
                int valorCombinacion = obtenerValorCombinacion(combinacion);
                if (valorCombinacion > maxValor) {
                    maxValor = valorCombinacion;
                    posiblesGanadores.clear();
                    posiblesGanadores.add(i);
                } else if (valorCombinacion == maxValor) {
                    posiblesGanadores.add(i);
                }
            }



            if (posiblesGanadores.size() > 1) {
                System.out.print("\nEmpate entre los jugadores: ");
                for (int idx : posiblesGanadores) {
                    System.out.print((idx + 1) + " ");
                }
                System.out.println();
                // Identificar el tipo de empate
                String tipoEmpate = identificarTipoEmpate(resultados, posiblesGanadores);
                System.out.println("Tipo de empate: " + tipoEmpate);
                int ganador = -1;
                // Lógica para manejar empates
                if (tipoEmpate.equals("Par")) {
                    ganador = desempatarPar(resultados, posiblesGanadores);
                } else if (tipoEmpate.equals("Doble par")) {
                    ganador = desempatarDoblePar(resultados, posiblesGanadores);
                } else if (tipoEmpate.equals("Tercia")) {
                    ganador = desempatarTercia(resultados, posiblesGanadores);
                } else if (tipoEmpate.equals("Full")) {
                    ganador = desempatarFull(resultados, posiblesGanadores);
                } else if (tipoEmpate.equals("Poker")) {
                    ganador = desempatarPoker(resultados, posiblesGanadores);
                } else if (tipoEmpate.equals("Quintilla")) {
                    ganador = desempatarQuintilla(resultados, posiblesGanadores);
                }
                if (ganador < 1 || ganador > numJugadores) {
                    System.out.println("No hay ganador");
                } else {
                    System.out.println("El jugador " + (ganador) + " ha ganado en el desempate.");
                    puntajeJugadores[(ganador-1)]+=1;
                }
            } else {
                System.out.println("\nEl jugador " + (posiblesGanadores.get(0) + 1) + " ha ganado");
                puntajeJugadores[((posiblesGanadores.get(0) + 1)-1)]+=1;
            }
            rondaActual++;
        }while(rondaActual != numRondas);
        ganadores = encontrarGanador(puntajeJugadores);
        if(ganadores.size()>1){
            System.out.println("\n\nNO HAY GANADOR EN ESTA PARTIDA");
        }else{
            System.out.println("\n\nEL GANADOR DE LA PARTIDA ES EL JUGADOR "+(ganadores.get(0)+1)+", FELICIDADES "
                    +nombresJugadores[ganadores.get(0)]);
        }
    }

    public static ArrayList<Integer> encontrarGanador(int[] puntajeJugadores) {
        ArrayList<Integer> ganador = new ArrayList<>();

        // Encontrar el valor máximo en el arreglo
        int maxPuntaje = puntajeJugadores[0];
        for (int i = 1; i < puntajeJugadores.length; i++) {
            if (puntajeJugadores[i] > maxPuntaje) {
                maxPuntaje = puntajeJugadores[i];
            }
        }

        // Guardar las posiciones de los valores más grandes
        for (int i = 0; i < puntajeJugadores.length; i++) {
            if (puntajeJugadores[i] == maxPuntaje) {
                ganador.add(i);
            }
        }

        return ganador;
    }

    // Método para identificar el tipo de empate
    // Método para identificar el tipo de empate
    private String identificarTipoEmpate(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores) {
        // Obtener los resultados de los jugadores empatados
        ArrayList<String> resultadoJugador1 = resultados[posiblesGanadores.get(0)];
        ArrayList<String> resultadoJugador2 = resultados[posiblesGanadores.get(1)];

        // Identificar la combinación obtenida por cada jugador
        String combinacionJugador1 = identificarCombinacion(resultadoJugador1);
        String combinacionJugador2 = identificarCombinacion(resultadoJugador2);

        // Verificar si es un empate de par y par
        if (combinacionJugador1.equals("Un par") && combinacionJugador2.equals("Un par")) {
            return "Par";
        }

        // Verificar si es un empate de doble par y doble par
        if (combinacionJugador1.equals("Dos pares") && combinacionJugador2.equals("Dos pares")) {
            return "Doble par";
        }

        // Verificar si es un empate de tercia y tercia
        if (combinacionJugador1.equals("Tercia") && combinacionJugador2.equals("Tercia")) {
            return "Tercia";
        }

        // Verificar si es un empate de full y full
        if (combinacionJugador1.equals("Full") && combinacionJugador2.equals("Full")) {
            return "Full";
        }

        // Verificar si es un empate de poker y poker
        if (combinacionJugador1.equals("Poker") && combinacionJugador2.equals("Poker")) {
            return "Poker";
        }

        // Verificar si es un empate de quintilla y quintilla
        if (combinacionJugador1.equals("Quintilla") && combinacionJugador2.equals("Quintilla")) {
            return "Quintilla";
        }

        // Si no coincide con ninguno de los anteriores, no hay empate
        return "No empate";
    }

    // Método para obtener el valor numérico de una carta
    /*private static int valorNumerico(String carta) {
        switch (carta) {
            //Juego Clasico
            case "9":
                return 9;
            case "10":
                return 10;
            case "J":
                return 11;
            case "Q":
                return 12;
            case "K":
                return 13;
            case "As":
                return 14;
            default:
                return -1;
        }
    }*/
    // Método para obtener el valor numérico de una carta
    private static int valorNumerico(String carta) {
        return switch (carta) {
            // Juego Clasico y Valores
            case "9", "Rosa", "B", "Ciencia" -> 9;
            case "10", "Morado", "C", "Matemáticas" -> 10;
            case "J", "Amarillo", "D", "Sistemas" -> 11;
            case "Q", "Verde", "E", "Digitales" -> 12;
            case "K", "Rojo", "F", "Circuitos" -> 13;
            case "As", "Azul", "G", "Programación" -> 14;
            default -> -1;
        };
    }


    // Método para obtener el valor de la combinación según las reglas del juego
    private static int obtenerValorCombinacion(String combinacion) {
        switch (combinacion) {
            case "Quintilla":
                return 6;
            case "Poker":
                return 5;
            case "Full":
                return 4;
            case "Tercia":
                return 3;
            case "Dos pares":
                return 2;
            case "Un par":
                return 1;
            default:
                return 0;
        }
    }

    @Override
    public int desempatarPar(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores) {
        // Crear una lista para almacenar los valores de los pares y el dado extra
        ArrayList<int[]> valoresJugadores = new ArrayList<>();

        // Iterar sobre los posibles ganadores para obtener los valores de los pares y el dado extra
        for (int idx : posiblesGanadores) {
            ArrayList<String> lanzamiento = resultados[idx];
            int[] valores = obtenerValoresPar(lanzamiento);
            valoresJugadores.add(valores);
        }

        // Comparar los valores para determinar el ganador
        int ganador = posiblesGanadores.get(0);
        int[] valoresGanador = valoresJugadores.get(0);

        boolean empate = true;
        for (int i = 1; i < posiblesGanadores.size(); i++) {
            int[] valoresActuales = valoresJugadores.get(i);
            int comparacion = compararValores(valoresActuales, valoresGanador);
            if (comparacion > 0) {
                ganador = posiblesGanadores.get(i);
                valoresGanador = valoresActuales;
                empate = false;
            } else if (comparacion < 0) {
                empate = false;
            }
        }

        if (empate) {
            return -1; // Indica que no hay ganador debido a un empate exacto
        }

        return ganador + 1; // Sumamos 1 porque los índices de los jugadores comienzan desde 0
    }

    // Método para obtener los valores del par mayor, par menor y dado extra de un lanzamiento
    private static int[] obtenerValoresPar(ArrayList<String> lanzamiento) {
        int[] valores = new int[3];
        int[] conteo = new int[15]; // Para contar las ocurrencias de cada carta (9 a As)

        for (String carta : lanzamiento) {
            conteo[valorNumerico(carta)]++;
        }

        int parMayor = -1;
        int parMenor = -1;
        int extra = -1;

        for (int i = 14; i >= 9; i--) {
            if (conteo[i] >= 2) {
                if (parMayor == -1) {
                    parMayor = i;
                    conteo[i] -= 2;
                } else {
                    parMenor = i;
                    conteo[i] -= 2;
                }
            }
        }

        // Obtener el valor del dado extra
        for (int i = 14; i >= 9; i--) {
            if (conteo[i] > 0) {
                extra = i;
                break;
            }
        }

        valores[0] = parMayor;
        valores[1] = parMenor;
        valores[2] = extra;
        return valores;
    }

    @Override
    public int desempatarDoblePar(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores) {
        // Arreglos para almacenar los valores de los pares y el dado extra de cada jugador
        int[][] valoresJugadores = new int[posiblesGanadores.size()][3];

        // Obtener los valores de los pares y el dado extra de cada jugador
        for (int i = 0; i < posiblesGanadores.size(); i++) {
            int idx = posiblesGanadores.get(i);
            ArrayList<String> lanzamiento = resultados[idx];

            int[] valores = obtenerValoresPares(lanzamiento);
            valoresJugadores[i][0] = valores[0]; // Par mayor
            valoresJugadores[i][1] = valores[1]; // Par menor
            valoresJugadores[i][2] = valores[2]; // Dado extra
        }

        // Comparar los valores para determinar el ganador
        int ganador = posiblesGanadores.get(0);
        int[] valoresGanador = valoresJugadores[0];

        boolean empate = true;
        for (int i = 1; i < posiblesGanadores.size(); i++) {
            int[] valoresActuales = valoresJugadores[i];
            int comparacion = compararValores(valoresActuales, valoresGanador);
            if (comparacion > 0) {
                ganador = posiblesGanadores.get(i);
                valoresGanador = valoresActuales;
                empate = false;
            } else if (comparacion < 0) {
                empate = false;
            }
        }

        if (empate) {
            return -1; // Indica que todos los valores son exactamente iguales
        }

        return ganador + 1; // Sumamos 1 porque los índices de los jugadores comienzan desde 0
    }

    // Método para obtener los valores de los pares y el dado extra de un lanzamiento
    private static int[] obtenerValoresPares(ArrayList<String> lanzamiento) {
        int[] valores = new int[3];
        int[] conteo = new int[15]; // Para contar las ocurrencias de cada carta (9 a As)

        for (String carta : lanzamiento) {
            conteo[valorNumerico(carta)]++;
        }

        ArrayList<Integer> pares = new ArrayList<>();
        int dadoExtra = -1;

        for (int i = conteo.length - 1; i >= 0; i--) {
            if (conteo[i] == 2) {
                pares.add(i);
            } else if (conteo[i] == 1) {
                dadoExtra = i;
            }
        }

        if (pares.size() >= 2) {
            valores[0] = pares.get(0); // Par mayor
            valores[1] = pares.get(1); // Par menor
        } else if (pares.size() == 1) {
            valores[0] = pares.get(0); // Par mayor
            valores[1] = -1; // No hay segundo par
        }

        valores[2] = dadoExtra; // Dado extra
        return valores;
    }

    // Método para comparar los valores de dos jugadores
    private static int compararValores(int[] valores1, int[] valores2) {
        for (int i = 0; i < 3; i++) {
            if (valores1[i] > valores2[i]) {
                return 1;
            } else if (valores1[i] < valores2[i]) {
                return -1;
            }
        }
        return 0; // Son iguales
    }

    @Override
    public int desempatarTercia(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores) {
        // Crear una lista para almacenar los valores de la tercia y la suma de los otros dos dados
        ArrayList<int[]> valoresJugadores = new ArrayList<>();

        // Iterar sobre los posibles ganadores para obtener los valores de la tercia y la suma de los otros dos dados
        for (int idx : posiblesGanadores) {
            ArrayList<String> lanzamiento = resultados[idx];
            int[] valores = obtenerValoresTercia(lanzamiento);
            valoresJugadores.add(valores);
        }

        // Comparar los valores para determinar el ganador
        int ganador = posiblesGanadores.get(0);
        int[] valoresGanador = valoresJugadores.get(0);

        boolean empate = true;
        for (int i = 1; i < posiblesGanadores.size(); i++) {
            int[] valoresActuales = valoresJugadores.get(i);
            int comparacion = compararValoresTercia(valoresActuales, valoresGanador);
            if (comparacion > 0) {
                ganador = posiblesGanadores.get(i);
                valoresGanador = valoresActuales;
                empate = false;
            } else if (comparacion < 0) {
                empate = false;
            }
        }

        if (empate) {
            return -1; // Indica que no hay ganador debido a un empate exacto
        }

        return ganador + 1; // Sumamos 1 porque los índices de los jugadores comienzan desde 0
    }

    // Método para obtener los valores de la tercia y la suma de los otros dos dados de un lanzamiento
    private static int[] obtenerValoresTercia(ArrayList<String> lanzamiento) {
        int[] valores = new int[2];
        int[] conteo = new int[15]; // Para contar las ocurrencias de cada carta (9 a As)

        for (String carta : lanzamiento) {
            conteo[valorNumerico(carta)]++;
        }

        int tercia = -1;
        int sumaOtros = 0;

        // Obtener la tercia
        for (int i = 14; i >= 9; i--) {
            if (conteo[i] >= 3) {
                tercia = i;
                conteo[i] -= 3;
                break;
            }
        }

        // Sumar los otros dos dados
        for (int i = 14; i >= 9; i--) {
            sumaOtros += conteo[i] * i;
        }

        valores[0] = tercia;
        valores[1] = sumaOtros;
        return valores;
    }

    // Método para comparar los valores de dos jugadores (tercia y suma de otros dos dados)
    private static int compararValoresTercia(int[] valores1, int[] valores2) {
        if (valores1[0] > valores2[0]) {
            return 1;
        } else if (valores1[0] < valores2[0]) {
            return -1;
        } else {
            if (valores1[1] > valores2[1]) {
                return 1;
            } else if (valores1[1] < valores2[1]) {
                return -1;
            }
        }
        return 0; // Son iguales
    }

    @Override
    public int desempatarFull(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores) {
        // Crear una lista para almacenar los valores de la tercia y el par
        ArrayList<int[]> valoresJugadores = new ArrayList<>();

        // Iterar sobre los posibles ganadores para obtener los valores de la tercia y el par
        for (int idx : posiblesGanadores) {
            ArrayList<String> lanzamiento = resultados[idx];
            int[] valores = obtenerValoresFull(lanzamiento);
            valoresJugadores.add(valores);
        }

        // Comparar los valores para determinar el ganador
        int ganador = posiblesGanadores.get(0);
        int[] valoresGanador = valoresJugadores.get(0);

        boolean empate = true;
        for (int i = 1; i < posiblesGanadores.size(); i++) {
            int[] valoresActuales = valoresJugadores.get(i);
            int comparacion = compararValoresFull(valoresActuales, valoresGanador);
            if (comparacion > 0) {
                ganador = posiblesGanadores.get(i);
                valoresGanador = valoresActuales;
                empate = false;
            } else if (comparacion < 0) {
                empate = false;
            }
        }

        if (empate) {
            return -1; // Indica que no hay ganador debido a un empate exacto
        }

        return ganador + 1; // Sumamos 1 porque los índices de los jugadores comienzan desde 0
    }

    // Método para obtener los valores de la tercia y el par de un lanzamiento
    private static int[] obtenerValoresFull(ArrayList<String> lanzamiento) {
        int[] valores = new int[2];
        int[] conteo = new int[15]; // Para contar las ocurrencias de cada carta (9 a As)

        for (String carta : lanzamiento) {
            conteo[valorNumerico(carta)]++;
        }

        int tercia = -1;
        int par = -1;

        // Obtener la tercia
        for (int i = 14; i >= 9; i--) {
            if (conteo[i] >= 3) {
                tercia = i;
                conteo[i] -= 3;
                break;
            }
        }

        // Obtener el par
        for (int i = 14; i >= 9; i--) {
            if (conteo[i] >= 2) {
                par = i;
                conteo[i] -= 2;
                break;
            }
        }

        valores[0] = tercia;
        valores[1] = par;
        return valores;
    }

    // Método para comparar los valores de dos jugadores (tercia y par)
    private static int compararValoresFull(int[] valores1, int[] valores2) {
        if (valores1[0] > valores2[0]) {
            return 1;
        } else if (valores1[0] < valores2[0]) {
            return -1;
        } else {
            if (valores1[1] > valores2[1]) {
                return 1;
            } else if (valores1[1] < valores2[1]) {
                return -1;
            }
        }
        return 0; // Son iguales
    }

    @Override
    public int desempatarPoker(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores) {
        // Arreglo para almacenar el valor del poker y el dado extra de cada jugador
        int[][] valoresJugadores = new int[posiblesGanadores.size()][2];

        // Obtener los valores del poker y el dado extra de cada jugador
        for (int i = 0; i < posiblesGanadores.size(); i++) {
            int idx = posiblesGanadores.get(i);
            ArrayList<String> lanzamiento = resultados[idx];

            int[] valores = obtenerValoresPoker(lanzamiento);
            valoresJugadores[i][0] = valores[0]; // Valor del poker
            valoresJugadores[i][1] = valores[1]; // Dado extra
        }

        // Comparar los valores para determinar el ganador
        int ganador = posiblesGanadores.get(0);
        int[] valoresGanador = valoresJugadores[0];

        boolean empate = true;
        for (int i = 1; i < posiblesGanadores.size(); i++) {
            int[] valoresActuales = valoresJugadores[i];
            int comparacion = compararValores(valoresActuales, valoresGanador);
            if (comparacion > 0) {
                ganador = posiblesGanadores.get(i);
                valoresGanador = valoresActuales;
                empate = false;
            } else if (comparacion < 0) {
                empate = false;
            }
        }

        if (empate) {
            return -1; // Indica que todos los valores son exactamente iguales
        }

        return ganador + 1; // Sumamos 1 porque los índices de los jugadores comienzan desde 0
    }

    // Método para obtener los valores del poker y el dado extra de un lanzamiento
    private static int[] obtenerValoresPoker(ArrayList<String> lanzamiento) {
        int[] valores = new int[2];
        int[] conteo = new int[15]; // Para contar las ocurrencias de cada carta (9 a As)

        for (String carta : lanzamiento) {
            conteo[valorNumerico(carta)]++;
        }

        int poker = -1;
        int dadoExtra = -1;

        for (int i = conteo.length - 1; i >= 0; i--) {
            if (conteo[i] == 4) {
                poker = i;
            } else if (conteo[i] == 1) {
                dadoExtra = i;
            }
        }

        valores[0] = poker; // Valor del poker
        valores[1] = dadoExtra; // Dado extra
        return valores;
    }

    @Override
    public int desempatarQuintilla(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores) {
        // Comparar el valor más alto de cada lanzamiento para determinar el ganador
        int ganador = posiblesGanadores.get(0);
        String valorAlto = obtenerValorMasAlto(resultados[ganador]);

        for (int i = 1; i < posiblesGanadores.size(); i++) {
            int idx = posiblesGanadores.get(i);
            String valorActual = obtenerValorMasAlto(resultados[idx]);

            if (valorActual.compareTo(valorAlto) > 0) {
                ganador = idx;
                valorAlto = valorActual;
            } else if (valorActual.compareTo(valorAlto) == 0) {
                // Hay empate
                return -1;
            }
        }

        return ganador + 1; // Sumamos 1 porque los índices de los jugadores comienzan desde 0
    }

    // Método para obtener el valor más alto de un lanzamiento de quintilla
    private static String obtenerValorMasAlto(ArrayList<String> lanzamiento) {
        return Collections.max(lanzamiento);
    }
}