//J.R.D.H - 1190267
import java.util.ArrayList;
import java.util.Collections;
public class DesempateCombinaciones extends Combinacion implements Desempate {

    //Método para desempatar pares y doblespares
    @Override
    public int desempatarPares(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores, boolean doblePar) {
        int ganador = posiblesGanadores.get(0); // Suponer que el primer jugador es el ganador
        int[] maxValores = obtenerValoresPares(resultados[ganador], doblePar); // Obtener los valores del primer posible ganador
        // Iterar para encontrar el verdadero ganador
        for (int i = 1; i < posiblesGanadores.size(); i++) {
            int[] valores = obtenerValoresPares(resultados[posiblesGanadores.get(i)], doblePar); // Obtener los valores del posible ganador actual
            if (compararValores(valores, maxValores) > 0) {
                ganador = posiblesGanadores.get(i); // Actualizar el ganador
                maxValores = valores;
            }
        }
        return ganador + 1;
    }

    // Método para obtener los valores de los pares y el dado extra de un lanzamiento
    public int[] obtenerValoresPares(ArrayList<String> lanzamiento, boolean doblePar) {
        int[] conteo = new int[15];
        for (String dado : lanzamiento) { // Iterar sobre cada dado en el lanzamiento
            conteo[valorNumerico(dado)]++; // Incrementar el contador de dados
        }
        int parMayor = -1;
        int parMenor = -1;
        int extra = -1;
        // Buscar pares mayores y menores
        for (int i = 14; i >= 9; i--) {
            if (conteo[i] >= 2) {
                if (parMayor == -1) {
                    parMayor = i;
                    conteo[i] -= 2;
                } else if (doblePar && parMenor == -1) {
                    parMenor = i;
                    conteo[i] -= 2;
                }
            }
        }
        // Buscar valor extra
        for (int i = 14; i >= 9; i--) {
            if (conteo[i] > 0) {
                extra = i;
                break;
            }
        }
        // Si no es doblePar, dejar parMenor como -1
        if (!doblePar) {
            parMenor = -1;
        }
        return new int[]{parMayor, parMenor, extra};
    }

    // Método para comparar los valores de dos jugadores
    public int compararValores(int[] valores1, int[] valores2) {
        for (int i = 0; i < 3; i++) { // Comparar los tres valores
            if (valores1[i] > valores2[i]) {
                return 1;// si valores1 es mayor
            } else if (valores1[i] < valores2[i]) {
                return -1;// Retornar -1 si valores1 es menor
            }
        }
        return 0; // empate
    }

    @Override
    public int desempatarTercia(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores) {
        ArrayList<int[]> valoresJugadores = new ArrayList<>();

        // Iterar sobre los posibles ganadores para obtener los valores de la tercia y la suma de los otros dos dados
        for (int idx : posiblesGanadores) {
            ArrayList<String> lanzamiento = resultados[idx];
            int[] valores = obtenerValoresTercia(lanzamiento);
            valoresJugadores.add(valores);
        }

        int ganador = posiblesGanadores.get(0); //Definir un ganador temporal para comparar con los demas
        int[] valoresGanador = valoresJugadores.get(0);
        //Asumir un empate y comparar
        boolean empate = true;
        for (int i = 1; i < posiblesGanadores.size(); i++) {
            int[] valoresActuales = valoresJugadores.get(i);
            int comparacion = compararValoresTercia(valoresActuales, valoresGanador);
            if (comparacion > 0) {
                ganador = posiblesGanadores.get(i);//Si el valor nuevo es mayor que el ganador actual cambiar
                valoresGanador = valoresActuales;
                empate = false;
            } else if (comparacion < 0) {
                empate = false;
            }
        }

        if (empate) {
            return -1; //empate
        }

        return ganador + 1;
    }

    // Método para obtener los valores de la tercia y la suma de los otros dos dados de un lanzamiento
    public static int[] obtenerValoresTercia(ArrayList<String> lanzamiento) {
        int[] valores = new int[2];
        int[] conteo = new int[15];

        for (String dado : lanzamiento) {
            conteo[valorNumerico(dado)]++;
        }
        int tercia = -1; // valor por defecto, si no se incicializa marca error
        int sumaOtros = 0; // suma de los otros dos dados

        // Obtener la tercia
        for (int i = 14; i >= 9; i--) {
            if (conteo[i] >= 3) {
                tercia = i;
                conteo[i] -= 3;
                break;
            }
        }
        // Sumar los otros dos dados
        for (int i = 14; i >= 9; i--) {
            sumaOtros += conteo[i] * i;
        }
        valores[0] = tercia;
        valores[1] = sumaOtros;
        return valores;
    }

    // Método para comparar los valores de dos jugadores (tercia y suma de otros dos dados)
    public static int compararValoresTercia(int[] valores1, int[] valores2) {
        if (valores1[0] > valores2[0]) {
            return 1; // Si la tercia de valores1 es mayor, retornar 1
        } else if (valores1[0] < valores2[0]) {
            return -1; // Si la tercia de valores1 es menor, retornar -1
        } else {//comparacion de la suma de los otros dos dados
            if (valores1[1] > valores2[1]) {
                return 1;
            } else if (valores1[1] < valores2[1]) {
                return -1;
            }
        }
        return 0; // Son iguales
    }

    @Override
    public int desempatarFull(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores) {
        ArrayList<int[]> valoresJugadores = new ArrayList<>();

        for (int idx : posiblesGanadores) {
            ArrayList<String> lanzamiento = resultados[idx]; // Obtener el lanzamiento del jugador
            int[] valores = obtenerValoresFull(lanzamiento); // Obtener los valores del full house del lanzamiento
            valoresJugadores.add(valores); // Agregar los valores del jugador al ArrayList
        }

        int ganador = posiblesGanadores.get(0); //Tomar como ganador temporal para comparar con los demas
        int[] valoresGanador = valoresJugadores.get(0); //Tomar su lanzamiento

        //Asumir que es empate, y comparar los valores de cada jugador
        boolean empate = true;
        for (int i = 1; i < posiblesGanadores.size(); i++) {
            int[] valoresActuales = valoresJugadores.get(i); // Obtener los valores del jugador actual
            int comparacion = compararValoresFull(valoresActuales, valoresGanador); // Comparar los valores del jugador actual
            if (comparacion > 0) {
                ganador = posiblesGanadores.get(i); // Si el jugador actual tiene mejor mano actualizar el ganador
                valoresGanador = valoresActuales;
                empate = false;
            } else if (comparacion < 0) {
                empate = false;
            }
        }

        if (empate) return -1;

        return ganador + 1;
    }

    public static int[] obtenerValoresFull(ArrayList<String> lanzamiento) {
        int[] valores = new int[2]; // Arreglo para almacenar los valores de la tercia y el par
        int[] conteo = new int[15];  // Arreglo para contar cuantas veces aparece cada valor

        for (String dado : lanzamiento) {
            conteo[valorNumerico(dado)]++;
        }
        int tercia = -1;
        int par = -1;
        // Buscar la tercia
        for (int i = 14; i >= 9; i--) {
            if (conteo[i] >= 3) {
                tercia = i;
                conteo[i] -= 3;
                break;
            }
        }
        // Buscar el par
        for (int i = 14; i >= 9; i--) {
            if (conteo[i] >= 2) {
                par = i;
                conteo[i] -= 2;
                break;
            }
        }
        valores[0] = tercia;
        valores[1] = par;
        return valores;
    }

    public static int compararValoresFull(int[] valores1, int[] valores2) {
        // Comparar las tercias
        if (valores1[0] > valores2[0]){
            return 1;
        } else if (valores1[0] < valores2[0]){ return -1;}
        // Si las tercias son iguales, comparar los pares
        else if (valores1[1] > valores2[1]){
            return 1;
        } else if (valores1[1] < valores2[1]){
            return -1;
        }
        return 0;
    }

    @Override
    public int desempatarPoker(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores) {
        int[][] valoresJugadores = new int[posiblesGanadores.size()][2];
        // Iterar sobre los posibles ganadores
        for (int i = 0; i < posiblesGanadores.size(); i++) {
            int idx = posiblesGanadores.get(i); // Obtener el índice del jugador
            ArrayList<String> lanzamiento = resultados[idx]; // Obtener el lanzamiento del jugador

            int[] valores = obtenerValoresPoker(lanzamiento);
            valoresJugadores[i][0] = valores[0]; // Guardar el valor del poker
            valoresJugadores[i][1] = valores[1]; // Guardar el valor del dado extra
        }
        int ganador = posiblesGanadores.get(0); // Definir como ganador temporal y comparar con los demas
        int[] valoresGanador = valoresJugadores[0]; // Obtener lanzamiento

        // Comparar los valores de cada jugador para determinar el ganador
        boolean empate = true;
        for (int i = 1; i < posiblesGanadores.size(); i++) {
            int[] valoresActuales = valoresJugadores[i];
            int comparacion = compararValores(valoresActuales, valoresGanador);
            if (comparacion > 0) {
                ganador = posiblesGanadores.get(i); // Si el jugador actual tiene mejores valores, actualizar el ganador
                valoresGanador = valoresActuales;
                empate = false;
            } else if (comparacion < 0) {
                empate = false;
            }
        }
        if (empate){
            return -1;
        }
        return ganador + 1;
    }

    public static int[] obtenerValoresPoker(ArrayList<String> lanzamiento) {
        int[] valores = new int[2];// Arreglo para almacenar los valores de la tercia y el par
        int[] conteo = new int[15];// Arreglo para contar cuantas veces aparece cada valor
        for (String dado : lanzamiento) { // Iterar sobre cada dado en el lanzamiento
            conteo[valorNumerico(dado)]++; // Incrementar el contador correspondiente al valor numérico del dado
        }

        int poker = -1;
        int dadoExtra = -1;

        for (int i = conteo.length - 1; i >= 0; i--) { // Buscar el poker
            if (conteo[i] == 4) {
                poker = i;
            } else if (conteo[i] == 1) {
                dadoExtra = i;
            }
        }
        valores[0] = poker;
        valores[1] = dadoExtra;
        return valores;
    }

    @Override
    public int desempatarQuintilla(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores) {
        int ganador = posiblesGanadores.get(0);// Definir la posición 0 como ganador de forma temporal
        String valorAlto = obtenerValorMasAlto(resultados[ganador]);// Tomar su mano como la mas alta, de forma temporal

        for (int i = 1; i < posiblesGanadores.size(); i++) {
            int idx = posiblesGanadores.get(i);// Tomar al resto de los jugadores para compararlos con el de la posición 0
            String valorActual = obtenerValorMasAlto(resultados[idx]);////Tomar su mano

            if (valorActual.compareTo(valorAlto) > 0) {//Realizar la comparacion
                ganador = idx;
                valorAlto = valorActual;
            } else if (valorActual.compareTo(valorAlto) == 0) {
                return -1;
            }
        }
        return ganador + 1;
    }

    public static String obtenerValorMasAlto(ArrayList<String> lanzamiento) {
        return Collections.max(lanzamiento);
    }

    public static int valorNumerico(String dado) {
        return switch (dado) {
            // Juego Clasico y Valores
            case "9", "Rosa", "B", "Ciencia" -> 9;
            case "10", "Morado", "C", "Matemáticas" -> 10;
            case "J", "Amarillo", "D", "Sistemas" -> 11;
            case "Q", "Verde", "E", "Digitales" -> 12;
            case "K", "Rojo", "F", "Circuitos" -> 13;
            case "As", "Azul", "G", "Programación" -> 14;
            default -> -1;
        };
    }

    // Identificar el tipo de empate en el que quedaron los jugadores con la puntuacion mas alta
    public String identificarTipoEmpate(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores) {
        // Obtener los resultados de los jugadores empatados
        ArrayList<String> resultadoJugador1 = resultados[posiblesGanadores.get(0)];
        ArrayList<String> resultadoJugador2 = resultados[posiblesGanadores.get(1)];

        // Identificar la combinación obtenida por cada jugador
        String combinacionJugador1 = identificarCombinacion(resultadoJugador1);
        String combinacionJugador2 = identificarCombinacion(resultadoJugador2);

        // Verificar si es un empate de par y par
        if (combinacionJugador1.equals("Un par") && combinacionJugador2.equals("Un par")) {
            return "Par";
        }
        // Verificar si es un empate de doble par y doble par
        if (combinacionJugador1.equals("Dos pares") && combinacionJugador2.equals("Dos pares")) {
            return "Doble par";
        }
        // Verificar si es un empate de tercia y tercia
        if (combinacionJugador1.equals("Tercia") && combinacionJugador2.equals("Tercia")) {
            return "Tercia";
        }
        // Verificar si es un empate de full y full
        if (combinacionJugador1.equals("Full") && combinacionJugador2.equals("Full")) {
            return "Full";
        }
        // Verificar si es un empate de poker y poker
        if (combinacionJugador1.equals("Poker") && combinacionJugador2.equals("Poker")) {
            return "Poker";
        }
        // Verificar si es un empate de quintilla y quintilla
        if (combinacionJugador1.equals("Quintilla") && combinacionJugador2.equals("Quintilla")) {
            return "Quintilla";
        }
        // Si no coincide con ninguno de los anteriores, no hay empate
        return "No empate";
    }
}