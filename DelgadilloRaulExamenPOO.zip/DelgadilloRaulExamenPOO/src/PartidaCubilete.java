//J.R.D.H - 1190267
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Random;

public class PartidaCubilete extends DesempateCombinaciones {

    private boolean primeraRonda;
    private int numRondas = 4;
    private int rondaActual;
    private String[] nombresJugadores;
    private int [] puntajeJugadores = {0,0,0,0};
    private ArrayList<Integer> ganadores;
    private int numJugadores;
    Random rand = new Random();

    // Método para jugar el juego clásico de cubilete
    public void jugarJuegoClasico(Scanner scanner, int tipoDado) {
        primeraRonda = true;
        rondaActual = 0;
        ArrayList<String> valoresOriginales = new ArrayList<>();
        //Dado para el primer lanzamiento
        if (tipoDado == 1) {
            valoresOriginales.addAll(Dado.VALORES);
        } else if (tipoDado == 2) {
            valoresOriginales.addAll(Dado.VALORES_2);
        } else if (tipoDado == 3) {
            valoresOriginales.addAll(Dado.VALORES_3);
        } else if (tipoDado == 4) {
            valoresOriginales.addAll(Dado.VALORES_4);
        }

        do {
            if (primeraRonda) {
                //Verificar que el número de rondas sea valido
                do {
                    System.out.print("\nIngrese el número de rondas: ");
                    numRondas = scanner.nextInt();
                    if (numRondas <= 0) {
                        System.out.println("Número de rondas inválido. Debe ser un número positivo.");
                    }
                } while (numRondas <= 0);
                //Verificar que el número de jugadores sea valido
                do {
                    System.out.print("\nIngrese el número de jugadores (2-4): ");
                    while (!scanner.hasNextInt()) {
                        System.out.println("Por favor, ingrese un número válido.");
                        scanner.next(); // Limpiar el búfer de entrada
                        System.out.print("\nIngrese el número de jugadores (2-4): ");
                    }
                    numJugadores = scanner.nextInt();
                    if (numJugadores < 2 || numJugadores > 4) {
                        System.out.println("\nNúmero de jugadores inválido. El juego solo admite de 2 a 4 jugadores.");
                    }
                } while (numJugadores < 2 || numJugadores > 4);

                nombresJugadores = new String[numJugadores];// Arreglo para almacenar los nombres de los jugadores
                int[] valoresLanzamientos = new int[numJugadores]; // Arreglo para almacenar los valores de los lanzamientos
                HashSet<Integer> lanzamientosRealizados = new HashSet<>();// Para validar que no haya repeticiones de lanzamientos

                // Solicitar los nombres de los jugadores
                for (int i = 0; i < numJugadores; i++) {
                    System.out.print("\nIngrese el nombre del jugador " + (i + 1) + ": ");
                    nombresJugadores[i] = scanner.next();
                }

                for (int i = 0; i < numJugadores; i++) {
                    int lanzamiento;
                    do {
                        lanzamiento = rand.nextInt(valoresOriginales.size()); // Simular lanzamiento de un dado
                    } while (lanzamientosRealizados.contains(lanzamiento));
                    valoresLanzamientos[i] = lanzamiento;
                    lanzamientosRealizados.add(lanzamiento);
                    System.out.println("Lanzamiento de " + nombresJugadores[i] + ": " + valoresOriginales.get(lanzamiento));
                }

                // Ordenar los valores de los lanzamientos de mayor a menor
                for (int i = 0; i < numJugadores - 1; i++) {
                    for (int j = 0; j < numJugadores - i - 1; j++) {
                        if (valoresLanzamientos[j] < valoresLanzamientos[j + 1]) {
                            int temp = valoresLanzamientos[j];
                            valoresLanzamientos[j] = valoresLanzamientos[j + 1];
                            valoresLanzamientos[j + 1] = temp;

                            // Intercambiar nombres de jugadores de acuerdo a la posición del lanzamiento
                            String tempNombre = nombresJugadores[j];
                            nombresJugadores[j] = nombresJugadores[j + 1];
                            nombresJugadores[j + 1] = tempNombre;
                        }
                    }
                }

                // Mostrar el orden de los jugadores según el resultado de los lanzamientos
                System.out.println("\nOrden de los jugadores:");
                for (int i = 0; i < numJugadores; i++) {
                    System.out.println("Jugador " + (i + 1) + ": " + nombresJugadores[i]);
                }

                primeraRonda = false; // Marca que la primera ronda ha terminado
            }
            System.out.println("---------------------------------------------------");
            System.out.println("Ronda "+(rondaActual+1));
            int numJugadores = nombresJugadores.length;
            ArrayList<String>[] resultados = new ArrayList[numJugadores];
            int maxValor = -1;
            ArrayList<Integer> posiblesGanadores = new ArrayList<>();
            int tiradas = 0;

            for (int i = 0; i < numJugadores; i++) {
                System.out.println("\nJugador " + (i + 1) + ":");
                JuegoClasico juego = new JuegoClasico(5, tipoDado);
                ArrayList<String> lanzamiento = new ArrayList<>();
                for (String valor : juego.getDados()) {
                    lanzamiento.add(valor);
                }

                Collections.sort(lanzamiento, (a, b) -> valorNumerico(b) - valorNumerico(a)); // Ordenar de mayor a menor
                resultados[i] = lanzamiento;
                System.out.println("Resultado del lanzamiento:");
                for (String valor : lanzamiento) {
                    System.out.print("[" + valor + "] ");
                }
                System.out.println();
                // Preguntar al jugador si quiere volver a tirar hasta 2 veces mas
                if (i == 0) {
                    while (tiradas < 2) {
                        System.out.print("¿Quieres volver a tirar? (Si / No): ");
                        String respuesta = scanner.next();
                        if (respuesta.equalsIgnoreCase("Si")) {
                            boolean posicionesValidas = false;
                            do {
                                try {
                                    System.out.print("Ingrese la posición de los dados que quieres volver a tirar (separados por comas): ");
                                    String posicionesStr = scanner.next();
                                    String[] posiciones = posicionesStr.split(",");
                                    boolean posicionesSonPositivas = true;

                                    // Obtener los valores disponibles para las posiciones seleccionadas
                                    for (String posStr : posiciones) {
                                        int pos = Integer.parseInt(posStr.trim());
                                        if (pos < 1) {
                                            posicionesSonPositivas = false;
                                            break;
                                        }
                                        pos = pos - 1; // Convertir a índice base 0
                                        String valor = valoresOriginales.get(rand.nextInt(valoresOriginales.size())); // Seleccionar aleatoriamente un valor de los originales
                                        lanzamiento.set(pos, valor);
                                    }


                                    if (!posicionesSonPositivas) {
                                        System.out.println("\nPor favor, ingresa solo números positivos.");
                                    } else {
                                        // Mostrar todos los valores de los dados después de la tirada
                                        System.out.println("Lanzamiento actualizado:");
                                        for (int k = 0; k < 5; k++) {
                                            System.out.print("[" + lanzamiento.get(k) + "] ");
                                        }
                                        System.out.println();
                                        tiradas++;
                                        posicionesValidas = true; // Si llegamos aquí, todas las posiciones son válidas
                                    }
                                } catch (NumberFormatException e) {
                                    System.out.println("\nPor favor, ingresa solo números separados por comas");
                                    scanner.nextLine(); // Limpiar el búfer de entrada
                                } catch (IndexOutOfBoundsException e) {
                                    System.out.println("La posición ingresada no es valida, realice otro intento");
                                    scanner.nextLine(); // Limpiar el búfer de entrada
                                }
                            } while (!posicionesValidas);
                        } else if (respuesta.equalsIgnoreCase("No")){
                            break; // El jugador decide no tirar más dados
                        }
                    }
                } else {
                    // Preguntar a los demás jugadores si quieren volver a tirar la misma cantidad de veces que el primer jugador
                    for (int j = 0; j < tiradas; j++) {
                        System.out.print("¿Quieres volver a tirar? (Si / No): ");
                        String respuesta = scanner.next();
                        if (respuesta.equalsIgnoreCase("Si")) {
                            boolean posicionesValidas = false;
                            do {
                                try {
                                    System.out.print("Ingrese la posición de los dados que quieres volver a tirar (separados por comas): ");
                                    String posicionesStr = scanner.next();
                                    String[] posiciones = posicionesStr.split(",");
                                    boolean posicionesSonPositivas = true;

                                    // Obtener los valores disponibles para las posiciones seleccionadas
                                    for (String posStr : posiciones) {
                                        int pos = Integer.parseInt(posStr.trim());
                                        if (pos < 1) {
                                            posicionesSonPositivas = false;
                                            break;
                                        }
                                        pos = pos - 1; // Convertir a índice base 0
                                        String valor = valoresOriginales.get(rand.nextInt(valoresOriginales.size())); // Seleccionar aleatoriamente un valor de los originales
                                        lanzamiento.set(pos, valor);
                                    }


                                    if (!posicionesSonPositivas) {
                                        System.out.println("\nPor favor, ingresa solo números positivos.");
                                    } else {
                                        // Mostrar todos los valores de los dados después de la tirada
                                        System.out.println("Lanzamiento actualizado:");
                                        for (int k = 0; k < 5; k++) {
                                            System.out.print("[" + lanzamiento.get(k) + "] ");
                                        }
                                        System.out.println();
                                        posicionesValidas = true; // Si llegamos aquí, todas las posiciones son válidas
                                    }
                                } catch (NumberFormatException e) {
                                    System.out.println("\nPor favor, ingresa solo números separados por comas.");
                                    scanner.nextLine(); // Limpiar el búfer de entrada
                                } catch (IndexOutOfBoundsException e) {
                                    System.out.println("\nPosición inválida. Asegúrate de ingresar posiciones dentro del rango de los dados.");
                                    scanner.nextLine(); // Limpiar el búfer de entrada
                                }
                            } while (!posicionesValidas);
                        } else if (respuesta.equalsIgnoreCase("No")){
                            break; // El jugador decide no tirar más dados
                        }
                    }
                }

                String combinacion = identificarCombinacion(lanzamiento);
                System.out.println("Combinación obtenida: " + combinacion);

                // Obtener el valor numérico de la combinación
                int valorCombinacion = obtenerValorCombinacion(combinacion);
                if (valorCombinacion > maxValor) {
                    maxValor = valorCombinacion;
                    posiblesGanadores.clear();
                    posiblesGanadores.add(i);
                } else if (valorCombinacion == maxValor) {
                    posiblesGanadores.add(i);
                }
            }

            if (posiblesGanadores.size() > 1) {
                // Identificar el tipo de empate
                String tipoEmpate = identificarTipoEmpate(resultados, posiblesGanadores);
                int ganador = -1;
                boolean doblePar;
                // Encontrar al ganador si hay un empate
                if (tipoEmpate.equals("Par")) {
                    doblePar = false;
                    ganador = desempatarPares(resultados, posiblesGanadores,doblePar);
                } else if (tipoEmpate.equals("Doble par")) {
                    doblePar = true;
                    ganador = desempatarPares(resultados, posiblesGanadores,doblePar);
                } else if (tipoEmpate.equals("Tercia")) {
                    ganador = desempatarTercia(resultados, posiblesGanadores);
                } else if (tipoEmpate.equals("Full")) {
                    ganador = desempatarFull(resultados, posiblesGanadores);
                } else if (tipoEmpate.equals("Poker")) {
                    ganador = desempatarPoker(resultados, posiblesGanadores);
                } else if (tipoEmpate.equals("Quintilla")) {
                    ganador = desempatarQuintilla(resultados, posiblesGanadores);
                }
                if (ganador < 1 || ganador > numJugadores) {
                    System.out.println("\nNo hay ganador en esta ronda");
                } else {
                    System.out.println("\nEl jugador " + (ganador) + " ha ganado esta ronda");
                    puntajeJugadores[(ganador-1)]+=1;
                }
            } else {
                System.out.println("\nEl jugador " + (posiblesGanadores.get(0) + 1) + " ha ganado esta ronda");
                puntajeJugadores[((posiblesGanadores.get(0) + 1)-1)]+=1;
            }
            rondaActual++;
        }while(rondaActual != numRondas);
        ganadores = JuegoClasico.encontrarGanador(puntajeJugadores);
        if(ganadores.size()>1){
            System.out.println("\n\nPUNTAJE DE LA PARTIDA:");
            for(int i=0;i<numJugadores;i++){
                System.out.println("JUGADOR "+(i+1)+": "+puntajeJugadores[i]);
            }
            System.out.println("\n\nNO HAY GANADOR EN ESTA PARTIDA");
            System.out.print("HAY EMPATE ENTRE: ");
            for (int i = 0; i < ganadores.size(); i++) {
                System.out.print("JUGADOR " + (ganadores.get(i) + 1));
                if (i < ganadores.size() - 1) {
                    System.out.print(", ");
                }
            }
        }else{
            System.out.println("\n\nPUNTAJE DE LA PARTIDA:");
            for(int i=0;i<numJugadores;i++){
                System.out.println("JUGADOR "+(i+1)+": "+puntajeJugadores[i]);
            }
            System.out.println("\n\nEL GANADOR DE LA PARTIDA ES EL JUGADOR "+(ganadores.get(0)+1)+", FELICIDADES "
                    +nombresJugadores[ganadores.get(0)]);
        }
        for (int i = 0; i<4; i++) {
            puntajeJugadores[i]=0;
        }
        System.out.println("\n---------------------------------------------------");
    }
}