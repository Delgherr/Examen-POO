import java.util.Random;

public class JuegoClasico implements Dado {
    private String[] dados;
    private int numDados;
    private int tipoDado;
    Random random = new Random();

    // Constructor vacío, inicializa con 5 dados por defecto y tipo de dado 1
    public JuegoClasico() {
        this(5, 1);
    }

    public JuegoClasico(int numDados, int tipoDado) {
        this.numDados = numDados;
        this.tipoDado = tipoDado;
        dados = new String[numDados];
        for (int i = 0; i < numDados; i++) {
            tirar(i, tipoDado); // Tirar los dados
        }
    }

    @Override
    public void tirar(int index, int valor) {
        if (valor == 1) {
            int valorIndex = random.nextInt(valores.length);
            dados[index] = valores[valorIndex];
        } else if (valor == 2) {
            int valorIndex = random.nextInt(valores2.length);
            dados[index] = valores2[valorIndex];
        } else if (valor == 3) {
            int valorIndex = random.nextInt(valores3.length);
            dados[index] = valores3[valorIndex];
        } else if (valor == 4) {
            int valorIndex = random.nextInt(valores4.length);
            dados[index] = valores4[valorIndex];
        }
    }

    public String[] getDados() {
        return dados;
    }

    // Constructor que acepta valores específicos para los dados
    public JuegoClasico(String[] valores) {
        this.numDados = valores.length;
        this.dados = valores;
    }
}
