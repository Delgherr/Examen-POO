import java.util.Random;

public class JuegoClasico implements Dado {
    private String[] dados;
    private int numDados;
    private int tipoDado;
    Random random = new Random();

    // Constructor vacío, inicializa con 5 dados por defecto y tipo de dado 1
    public JuegoClasico() {
        this(5, 1);
    }

    public JuegoClasico(int numDados, int tipoDado) {
        this.numDados = numDados;
        this.tipoDado = tipoDado;
        dados = new String[numDados];
        for (int i = 0; i < numDados; i++) {
            tirar(i, tipoDado); // Tirar los dados
        }
    }

    @Override
    public void tirar(int index, int valor) {
        if (valor == 1) {
            int valorIndex = random.nextInt(valores.length);
            dados[index] = valores[valorIndex];
        } else if (valor == 2) {
            int valorIndex = random.nextInt(valores2.length);
            dados[index] = valores2[valorIndex];
        } else if (valor == 3) {
            int valorIndex = random.nextInt(valores3.length);
            dados[index] = valores3[valorIndex];
        } else if (valor == 4) {
            int valorIndex = random.nextInt(valores4.length);
            dados[index] = valores4[valorIndex];
        }
    }

    public String[] getDados(){
        return dados;

    }
    public static String[] getDados(int tipo) {
        if (tipo == 1) {
            return valores;
        } else if (tipo == 2) {
            return valores2;
        } else if (tipo == 3) {
            return valores;
        } else if (tipo == 4) {
            return valores4;
        } else {
            return new String[0]; // Devuelve un arreglo vacío si tipo no coincide con ningún caso
        }
    }

    public String tirarDado(int tipoDado) {
        int valorIndex;
        if (tipoDado == 1) {
            valorIndex = random.nextInt(valores.length);
            return valores[valorIndex];
        } else if (tipoDado == 2) {
            valorIndex = random.nextInt(valores2.length);
            return valores2[valorIndex];
        } else if (tipoDado == 3) {
            valorIndex = random.nextInt(valores3.length);
            return valores3[valorIndex];
        } else if (tipoDado == 4) {
            valorIndex = random.nextInt(valores4.length);
            return valores4[valorIndex];
        } else {
            return null; // Devuelve null si el tipo de dado no coincide con ningún caso
        }
    }


    // Constructor que acepta valores específicos para los dados
    public JuegoClasico(String[] valores) {
        this.numDados = valores.length;
        this.dados = valores;
    }
}
