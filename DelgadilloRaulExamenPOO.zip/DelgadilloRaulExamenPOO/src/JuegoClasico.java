//J.R.D.H - 1190267
import java.util.ArrayList;
import java.util.Random;

public class JuegoClasico implements Dado {
    private String[] dados;
    private int numDados;
    private int tipoDado;
    Random random = new Random();

    // Constructor de la clase JuegoClasico
    public JuegoClasico(int numDados, int tipoDado) {
        this.numDados = numDados;
        this.tipoDado = tipoDado;
        dados = new String[numDados];
        for (int i = 0; i < numDados; i++) {
            tirar(i, tipoDado); // Tirar los dados
        }
    }
    // Método para obtener los valores actuales de los dados
    public String[] getDados(){
        return dados;
    }

    // Método estático para encontrar el ganador entre los jugadores
    public static ArrayList<Integer> encontrarGanador(int[] puntajeJugadores) {
        ArrayList<Integer> ganador = new ArrayList<>();
        // Encontrar el valor máximo en el arreglo
        int maxPuntaje = puntajeJugadores[0]; // Suponer que el primer jugador tiene el puntaje más alto
        for (int i = 1; i < puntajeJugadores.length; i++) {
            if (puntajeJugadores[i] > maxPuntaje) {
                maxPuntaje = puntajeJugadores[i]; // Actualizar el puntaje si se encuentra un puntaje mayor
            }
        }
        // Guardar las posiciones de los jugadores con el puntaje más alto
        for (int i = 0; i < puntajeJugadores.length; i++) {
            if (puntajeJugadores[i] == maxPuntaje) {
                ganador.add(i);
            }
        }
        return ganador;
    }

    // Implementación del método de la interfaz Dado
    @Override
    public void tirar(int index, int valor) {
        // Dependiendo del valor del tipo de dado, seleccionar un conjunto diferente
        if (valor == 1) {
            int valorIndex = random.nextInt(VALORES.size());
            dados[index] = VALORES.get(valorIndex);
        } else if (valor == 2) {
            int valorIndex = random.nextInt(VALORES_2.size());
            dados[index] = VALORES_2.get(valorIndex);
        } else if (valor == 3) {
            int valorIndex = random.nextInt(VALORES_3.size());
            dados[index] = VALORES_3.get(valorIndex);
        } else if (valor == 4) {
            int valorIndex = random.nextInt(VALORES_4.size());
            dados[index] = VALORES_4.get(valorIndex);
        }
    }
}