interface Dado {
    public static final String[] valores = {"9", "10", "J", "Q", "K", "As"};
    public static final String[] valores2 = {"Rosa", "Morado", "Amarillo", "Verde", "Rojo", "Azul"};
    public static final String[] valores3 = {"B", "C", "D", "E", "F","G"};
    public static final String[] valores4 = {"Ciencia", "Matemáticas", "Sistemas", "Digitales", "Circuitos", "Programación"};

    public void tirar(int index, int valor);
}

