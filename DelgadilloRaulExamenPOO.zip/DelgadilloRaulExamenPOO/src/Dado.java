//J.R.D.H - 1190267
import java.util.List;
import java.util.ArrayList;

interface Dado {
    //Dados a elegir según el tipo de variante
    public static final ArrayList<String> VALORES = new ArrayList<>(List.of("9", "10", "J", "Q", "K", "As"));
    public static final ArrayList<String> VALORES_2 = new ArrayList<>(List.of("Rosa", "Morado", "Amarillo", "Verde", "Rojo", "Azul"));
    public static final ArrayList<String> VALORES_3 = new ArrayList<>(List.of("B", "C", "D", "E", "F", "G"));
    public static final ArrayList<String> VALORES_4 = new ArrayList<>(List.of("Ciencia", "Matemáticas", "Sistemas", "Digitales", "Circuitos", "Programación"));

    public void tirar(int index, int valor);
}