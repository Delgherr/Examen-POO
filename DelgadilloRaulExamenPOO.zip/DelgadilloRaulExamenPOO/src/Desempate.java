import java.util.ArrayList;

public interface Desempate {

    public int desempatarPar(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores);
    public int desempatarDoblePar(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores);
    public int desempatarTercia(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores);
    public int desempatarFull(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores);
    public int desempatarPoker(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores);
    public int desempatarQuintilla(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores);
}
