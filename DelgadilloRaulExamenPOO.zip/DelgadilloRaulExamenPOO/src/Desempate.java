//J.R.D.H - 1190267
import java.util.ArrayList;

public interface Desempate {
    public int desempatarPares(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores, boolean doblePar);
    public int desempatarTercia(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores);
    public int desempatarFull(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores);
    public int desempatarPoker(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores);
    public int desempatarQuintilla(ArrayList<String>[] resultados, ArrayList<Integer> posiblesGanadores);
}